Thank you for downloading AnimDessin2 CC2015! 

I hope it saves you a bunch of time. 

# How to install

AnimDessin2 CC2015 requires Photoshop CC 2015 or newer.

If you have that then open it up and go to **File → Scripts → Browse...** and **select the installer.jsx file** in the same folder as these instructions. The rest is handled automatically.

## Manual install ##

You need to install by yourself the "**AnimDessin2_Scripts**" folder in the Scripts folder.

**Mac:** Applications/Adobe Photoshop CC 2015/Presets/Scripts/

**Win:** C:\Program Files\Adobe\Adobe Photoshop CC 2015\Presets\Scripts\

---

# How AnimDessin2 CC2015 works

This panel is designed for Photoshop CC 2015. It allows you to draw animations frame-by-image (cel-animation), simplifying the process. it also lets you test the movie and set the duration of a keyframe…

* Video overview: https://vimeo.com/album/1989753 
* More info on my Animation Panels: http://sbaril.me/#photoshop-animation

---

# License

The AnimDessin2 CC2015 Photoshop extension is created by Stéphane Baril.

It's completely free to use!



###### And please, show me what you do with it ;) 


Email: colorisation@gmail.com

Twitter: https://twitter.com/sbaril